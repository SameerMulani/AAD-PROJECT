package com.example.project;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;


public class Cars extends Fragment {


    public Cars() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_cars, container, false);
    }
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Spinner spinner;
        TextView desc;
        spinner = view.findViewById(R.id.spin);


        ArrayList<String> arr = new ArrayList<>();

        arr.add("SUV");
        arr.add("SEDAN");


        ArrayAdapter<String> adap = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item,arr);
        spinner.setAdapter(adap);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 0:
                       loadFrag(new Suv());
                        break;
                    case 1:
                        loadFrag(new Sedan());
                        break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                loadFrag(new Suv());

            }
        });

    }
    public void loadFrag(Fragment fragment){
        FragmentManager fm = getChildFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.add(R.id.container, fragment);
        ft.commit();
    }


}