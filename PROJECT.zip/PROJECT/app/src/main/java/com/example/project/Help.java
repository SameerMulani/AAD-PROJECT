package com.example.project;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;


public class Help extends Fragment {

    public Help() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_help, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Button dial = view.findViewById(R.id.btndialer);
        Button mail = view.findViewById(R.id.btnmail);
        Button insta = view.findViewById(R.id.btni);

        dial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent iDial = new Intent(Intent.ACTION_DIAL);
                iDial.setData(Uri.parse("tel:+918976650090"));
                startActivity(iDial);
            }
        });

        mail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent iMail = new Intent(Intent.ACTION_DIAL);
                iMail.setType("message/rfc822");
                iMail.putExtra(Intent.EXTRA_EMAIL,new String[]{"Sameermulani.9802@gmail.com"});
                iMail.putExtra(Intent.EXTRA_SUBJECT,"FIRST MAIL USING AAD");
                iMail.putExtra(Intent.EXTRA_TEXT,"HELLO, THIS IS SAMEER FROM FUTURE!!!");
                startActivity(Intent.createChooser(iMail,"Email Via"));
            }
        });

        insta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                WebView wb = view.findViewById(R.id.webview);
                wb.loadUrl("https://www.instagram.com/bmwindia_official/");
                wb.setWebViewClient(new WebViewClient());
            }
        });
    }


}